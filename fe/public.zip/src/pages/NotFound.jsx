import React from 'react'

export default function NotFound() {
  return (
    <div>
      <p>Not found</p>  
    </div>
  )
}
